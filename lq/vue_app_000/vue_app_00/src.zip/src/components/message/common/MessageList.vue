<template>
  <div>
    <h1>消息列表子组件 MessageList.vue</h1>
     <!--3:调用(一条消息)子组件 14:37-->
     <message
       :imgurl="require('../../../assets/a_7.png')"
       title="好消息"
       subtitle="好一条好消息"
       sendtime="09:45"
     ></message>
  </div>
</template>
<script>
//<!--1:引入(一条消息)子组件-->
import Message from "./Message.vue"
export default {
  data(){
    return {}
  },
  components:{//<!--2:注册(一条消息)子组件-->
    "message":Message
  }
}
</script>

