<template>
  <div>
    <!--Home.vue-->
    <!--3:调用TitleBar 传参数leftTitle-->
    <titlebar 
    leftTitle="微信(11)"
    :rightFirstImg="require('../../assets/ic_search.png')"
    :rightSecondImg="require('../../assets/ic_add.png')"
    :search="mysearch"
    :add3="myadd3"
    ></titlebar>
  </div>
</template>
<script>
//<!--1:引入TitleBar.vue-->
import TitleBar from "./common/TitleBar.vue"
export default {
   data(){
     return {}
   },//<!--2:注册TitleBar9:49-->
   methods:{
     mysearch(){
       //titleBar子组件所需处理函数:搜索
       console.log("搜索")
     },
     myadd3(){
       //titleBar子组件所需处理函数:添加
       console.log("添加")
     }
   },
   components:{
     "titlebar":TitleBar
   }
}
</script>

