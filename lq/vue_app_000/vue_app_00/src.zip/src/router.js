import Vue from 'vue'
import Router from 'vue-router'
import HelloContainer from "./components/HelloWorld.vue"
import Home from "./components/weixin/Home.vue"

//#为Exam01.vue 组件指定访问路径
//1:在router.js 引入组件
import Exam01 from "./components/exam/Exam01.vue"
//2:为组件指定访问路径 /Exam01
import Exam02 from
"./components/exam/Exam02.vue"
import Exam03 from "./components/exam/Exam03.vue"
import ExamContainer04 from "./components/exam/ExamContainer04.vue"
import ExamContainer05 from "./components/exam/ExamContainer05.vue"
import ExamTabbar06 from "./components/exam/ExamTabbar06.vue"
import Fa08 from "./components/exam/Fa08.vue"
//微信消息列表组件
import Home3 from "./components/message/Home.vue"
import MessageList from "./components/message/common/MessageList.vue"
Vue.use(Router)
export default new Router({
  routes: [
    //组件访问路径15    组件名  /MessageList
    {path:'/MessageList',component:MessageList},
    {path:'/Home3',component:Home3},
    {path:'/Fa08',component:Fa08},
    {path:'/ExamTabbar06',component:ExamTabbar06},
    {path:'/ExamContainer05',component:ExamContainer05},
    {path:'/ExamContainer04',component:ExamContainer04},
    {path:'/Exam03',component:Exam03},
    {path:'/Exam02',component:Exam02},
    {path:'/Home',component:Home},
    {path:'/',component:HelloContainer},
    {path:'/Exam01',component:Exam01}
  ]
})
